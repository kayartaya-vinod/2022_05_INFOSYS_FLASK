import React from 'react';

function Header() {
    return (
        <>
            <div className='alert alert-primary'>
                <div className='container'>
                    <h1>Customer dashboard app</h1>
                </div>
            </div>
        </>
    );
}

export default Header;
