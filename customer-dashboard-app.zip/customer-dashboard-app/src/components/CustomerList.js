import axios from 'axios';
import { useState, useEffect } from 'react';

function CustomerList() {
    const [customers, setCustomers] = useState([]);

    useEffect(() => {
        (async () => {
            const resp = await axios.get('http://localhost:8080/api/customers');
            setCustomers(resp.data);
        })();
    }, []);

    let customerRows = customers.map((c) => (
        <tr key={c.id}>
            <td></td>
            <td>{c.firstname + ' ' + c.lastname}</td>
            <td>{c.email}</td>
            <td>{c.phone}</td>
            <td>{c.city}</td>
        </tr>
    ));

    return (
        <>
            <h3>List of customers</h3>
            <table className='table table-bordered table-hover table-striped'>
                <thead>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Email address</th>
                        <th>Phone number</th>
                        <th>City</th>
                    </tr>
                </thead>

                <tbody>{customerRows}</tbody>
            </table>
        </>
    );
}

export default CustomerList;
