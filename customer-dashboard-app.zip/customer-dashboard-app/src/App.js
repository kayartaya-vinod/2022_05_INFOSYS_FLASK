import CustomerList from './components/CustomerList';
import Header from './components/Header';

function App() {
    return (
        <>
            <Header />
            <div className='container'>
                <CustomerList />
            </div>
        </>
    );
}

export default App;
